export { parseArgsStringToArgv as default, parseArgsStringToArgv };
declare function parseArgsStringToArgv(value: string, env?: string, file?: string): string[];
