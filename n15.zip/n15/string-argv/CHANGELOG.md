# Changelog

## v0.3.0 (2019-04-16)
**Dev Experience Changes**
- Project now compiled with TypeScript and provides typings

## v0.2.0 (2019-04-14)
**Parsing Behavior Changes**
- Now parses multiple nested quotes and content when there are no spaces [7d9b897](https://github.com/mccormicka/string-argv/commit/7d9b89730ea112b829f2591e3e9cae4c0d0cc285)