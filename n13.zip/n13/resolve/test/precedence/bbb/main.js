console.log(require('./')); // should throw
