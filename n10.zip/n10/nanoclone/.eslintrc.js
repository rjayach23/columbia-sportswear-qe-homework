module.exports = {
    "extends": "standard",

    "env": {
        "node": true,
        "jest": true
    }
};