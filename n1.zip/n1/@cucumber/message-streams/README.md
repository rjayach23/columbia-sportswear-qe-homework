# Cucumber Message Streams

This module contains stream utilities to read/write Cucumber Message objects
to/from streams.
