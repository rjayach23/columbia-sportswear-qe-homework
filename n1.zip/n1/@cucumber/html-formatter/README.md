⚠️ This is an internal package; you don't need to install it in order to use the html formatter in `@cucumber/cucumber` as it's built in there.

# html-formatter

> Takes a stream of Cucumber messages and outputs a standalone HTML report using Cucumber's React components
