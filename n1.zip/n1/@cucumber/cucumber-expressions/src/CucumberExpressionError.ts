export default class CucumberExpressionError extends Error {}
