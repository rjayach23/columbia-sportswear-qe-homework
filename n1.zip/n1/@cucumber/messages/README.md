# Cucumber Messages for JavaScript (JSON schema)

