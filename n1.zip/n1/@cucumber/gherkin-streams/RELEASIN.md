See [.github/RELEASING](https://github.com/cucumber/.github/blob/main/RELEASING.md).
