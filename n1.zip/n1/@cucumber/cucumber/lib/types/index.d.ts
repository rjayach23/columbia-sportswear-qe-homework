export interface ILineAndUri {
    line: number;
    uri: string;
}
