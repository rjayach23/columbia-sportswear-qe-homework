import { InternalPlugin } from '../plugin';
import { IPublishConfig } from './types';
export declare const publishPlugin: InternalPlugin<IPublishConfig | false>;
