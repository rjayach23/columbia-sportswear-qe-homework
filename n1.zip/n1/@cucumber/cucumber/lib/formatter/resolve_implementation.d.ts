import { FormatterImplementation } from './index';
export declare function resolveImplementation(specifier: string, cwd: string): Promise<FormatterImplementation>;
