export declare function importCode(specifier: string, cwd: string): Promise<any>;
