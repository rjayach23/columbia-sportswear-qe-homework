export declare function findClassOrPlugin(imported: any): any;
