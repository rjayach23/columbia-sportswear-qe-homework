import { Duration } from '@cucumber/messages';
export declare function durationToNanoseconds(duration: Duration): number;
