import * as messages from '@cucumber/messages';
export declare function formatStepArgument(arg: messages.PickleStepArgument): string;
