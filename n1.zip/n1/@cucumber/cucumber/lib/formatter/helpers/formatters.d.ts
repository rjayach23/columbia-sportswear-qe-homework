import Formatter from '../.';
declare const Formatters: {
    getFormatters(): Record<string, typeof Formatter>;
};
export default Formatters;
