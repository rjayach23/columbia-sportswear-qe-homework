import { ILineAndUri } from '../../types';
export declare function formatLocation(obj: ILineAndUri, cwd?: string): string;
