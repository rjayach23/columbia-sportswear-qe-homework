import { FormatterImplementation } from '../index';
declare const builtin: Record<string, FormatterImplementation>;
export default builtin;
