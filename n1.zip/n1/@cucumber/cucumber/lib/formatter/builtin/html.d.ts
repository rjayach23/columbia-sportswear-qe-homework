declare const _default: {
    type: "formatter";
    formatter({ on, write }: import("../../plugin").FormatterPluginContext<any>): () => Promise<void>;
    documentation: string;
};
export default _default;
