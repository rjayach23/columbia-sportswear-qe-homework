export declare function makeProxy<T>(getThing: () => any): T;
