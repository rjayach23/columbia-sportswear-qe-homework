import { StackFrame } from 'error-stack-parser';
export declare function isFileNameInCucumber(fileName: string): boolean;
export declare function filterStackTrace(frames: StackFrame[]): StackFrame[];
