export type GherkinStepKeyword = 'Unknown' | 'Given' | 'When' | 'Then';
