import Definition from './definition';
export default class TestRunHookDefinition extends Definition {
}
