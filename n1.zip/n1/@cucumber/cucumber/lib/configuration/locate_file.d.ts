export declare function locateFile(cwd: string): string | undefined;
