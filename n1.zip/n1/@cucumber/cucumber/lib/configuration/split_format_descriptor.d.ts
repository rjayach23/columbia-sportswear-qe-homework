import { ILogger } from '../logger';
export declare function splitFormatDescriptor(logger: ILogger, option: string): string[];
