import { IConfiguration } from './types';
export declare function checkSchema(configuration: any): Partial<IConfiguration>;
