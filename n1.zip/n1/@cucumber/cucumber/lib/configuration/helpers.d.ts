export declare function isTruthyString(s: string | undefined): boolean;
