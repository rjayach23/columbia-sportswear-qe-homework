import { IConfiguration } from './types';
export declare const DEFAULT_CONFIGURATION: IConfiguration;
