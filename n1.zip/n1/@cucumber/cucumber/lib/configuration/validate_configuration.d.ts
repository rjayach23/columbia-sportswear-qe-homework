import { ILogger } from '../logger';
import { IConfiguration } from './types';
export declare function validateConfiguration(configuration: IConfiguration, logger: ILogger): void;
