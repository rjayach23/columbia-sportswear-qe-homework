export declare function validateInstall(): Promise<void>;
