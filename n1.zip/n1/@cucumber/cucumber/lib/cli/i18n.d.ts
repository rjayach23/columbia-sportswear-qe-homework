export declare function getLanguages(): string;
export declare function getKeywords(isoCode: string): string;
