export declare const coordinatorVoidKeys: readonly ["message", "paths:resolve"];
export declare const coordinatorTransformKeys: readonly ["pickles:filter", "pickles:order"];
