import { InternalPlugin } from '../plugin';
import { ISourcesCoordinates } from '../api';
export declare const filterPlugin: InternalPlugin<ISourcesCoordinates>;
