export interface IContext<ParametersType = any> {
    readonly parameters: ParametersType;
}
