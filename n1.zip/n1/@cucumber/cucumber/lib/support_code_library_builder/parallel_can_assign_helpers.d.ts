import { ParallelAssignmentValidator } from './types';
export declare function atMostOnePicklePerTag(tagNames: string[]): ParallelAssignmentValidator;
