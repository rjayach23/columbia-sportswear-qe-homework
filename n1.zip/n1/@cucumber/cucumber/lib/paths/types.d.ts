export interface IResolvedPaths {
    unexpandedSourcePaths: string[];
    sourcePaths: string[];
    requirePaths: string[];
    importPaths: string[];
}
