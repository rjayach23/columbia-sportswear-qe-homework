import { Options } from "no-case";
export { Options };
export declare function capitalCaseTransform(input: string): string;
export declare function capitalCase(input: string, options?: Options): string;
