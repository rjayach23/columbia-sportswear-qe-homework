export * from './get-global.util';
export * from './is-promise.util';
//# sourceMappingURL=index.js.map