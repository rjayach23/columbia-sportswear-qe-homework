export {};
//# sourceMappingURL=type-help-options.interface.js.map