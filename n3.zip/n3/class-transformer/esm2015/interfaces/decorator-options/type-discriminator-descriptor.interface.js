export {};
//# sourceMappingURL=type-discriminator-descriptor.interface.js.map