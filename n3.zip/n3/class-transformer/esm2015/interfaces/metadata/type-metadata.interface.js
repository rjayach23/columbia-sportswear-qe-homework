export {};
//# sourceMappingURL=type-metadata.interface.js.map