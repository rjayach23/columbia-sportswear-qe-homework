export {};
//# sourceMappingURL=transform-fn-params.interface.js.map