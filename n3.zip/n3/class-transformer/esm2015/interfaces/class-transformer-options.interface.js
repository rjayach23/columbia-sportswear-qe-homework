export {};
//# sourceMappingURL=class-transformer-options.interface.js.map