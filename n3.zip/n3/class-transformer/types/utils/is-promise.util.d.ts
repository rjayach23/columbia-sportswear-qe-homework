export declare function isPromise<T>(p: any): p is Promise<T>;
