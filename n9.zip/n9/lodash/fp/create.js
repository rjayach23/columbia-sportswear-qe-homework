var convert = require('./convert'),
    func = convert('create', require('../create'));

func.placeholder = require('./placeholder');
module.exports = func;
