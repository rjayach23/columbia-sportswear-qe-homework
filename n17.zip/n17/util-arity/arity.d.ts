declare function arity (arity: number, fn: (...args: any[]) => any): (...args: any[]) => any;

export = arity;
