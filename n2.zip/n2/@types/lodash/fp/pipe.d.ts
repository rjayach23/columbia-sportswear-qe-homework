import { pipe } from "../fp";
export = pipe;
