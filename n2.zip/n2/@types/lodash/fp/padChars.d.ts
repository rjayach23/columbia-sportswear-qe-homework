import { padChars } from "../fp";
export = padChars;
