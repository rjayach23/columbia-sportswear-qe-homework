import { xor } from "../fp";
export = xor;
