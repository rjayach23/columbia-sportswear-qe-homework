import { takeWhile } from "../fp";
export = takeWhile;
