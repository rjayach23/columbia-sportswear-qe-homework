import { padEnd } from "../fp";
export = padEnd;
