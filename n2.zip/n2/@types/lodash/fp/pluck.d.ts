import { pluck } from "../fp";
export = pluck;
