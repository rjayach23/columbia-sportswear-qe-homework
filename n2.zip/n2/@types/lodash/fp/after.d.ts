import { after } from "../fp";
export = after;
