import { isEmpty } from "../fp";
export = isEmpty;
