import { zipWith } from "../fp";
export = zipWith;
