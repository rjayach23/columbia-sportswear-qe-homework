import { upperFirst } from "../fp";
export = upperFirst;
