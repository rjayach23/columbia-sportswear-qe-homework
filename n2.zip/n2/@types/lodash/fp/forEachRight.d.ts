import { forEachRight } from "../fp";
export = forEachRight;
