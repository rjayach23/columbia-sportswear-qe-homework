import { contains } from "../fp";
export = contains;
