import { defaultsDeepAll } from "../fp";
export = defaultsDeepAll;
