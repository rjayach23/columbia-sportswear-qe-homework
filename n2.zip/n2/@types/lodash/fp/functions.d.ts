import { functions } from "../fp";
export = functions;
