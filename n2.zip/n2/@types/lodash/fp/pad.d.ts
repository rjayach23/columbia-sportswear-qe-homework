import { pad } from "../fp";
export = pad;
