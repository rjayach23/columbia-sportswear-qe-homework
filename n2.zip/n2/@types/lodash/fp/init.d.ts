import { init } from "../fp";
export = init;
