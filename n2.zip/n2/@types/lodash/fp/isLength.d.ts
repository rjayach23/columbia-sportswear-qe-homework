import { isLength } from "../fp";
export = isLength;
