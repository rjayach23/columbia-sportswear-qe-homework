import { getOr } from "../fp";
export = getOr;
