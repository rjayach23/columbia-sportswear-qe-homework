import { xorWith } from "../fp";
export = xorWith;
