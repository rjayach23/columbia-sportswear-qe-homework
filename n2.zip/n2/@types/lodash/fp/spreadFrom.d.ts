import { spreadFrom } from "../fp";
export = spreadFrom;
