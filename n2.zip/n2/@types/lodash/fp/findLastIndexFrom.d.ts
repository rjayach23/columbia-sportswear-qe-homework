import { findLastIndexFrom } from "../fp";
export = findLastIndexFrom;
