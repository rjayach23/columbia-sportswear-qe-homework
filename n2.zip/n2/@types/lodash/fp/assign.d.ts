import { assign } from "../fp";
export = assign;
