import { zip } from "../fp";
export = zip;
