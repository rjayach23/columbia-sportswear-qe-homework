import { identity } from "../fp";
export = identity;
