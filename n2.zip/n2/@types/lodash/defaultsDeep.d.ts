import { defaultsDeep } from "./index";
export = defaultsDeep;
