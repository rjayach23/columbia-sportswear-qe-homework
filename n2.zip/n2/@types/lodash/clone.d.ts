import { clone } from "./index";
export = clone;
