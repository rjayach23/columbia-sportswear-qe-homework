import { entries } from "./index";
export = entries;
