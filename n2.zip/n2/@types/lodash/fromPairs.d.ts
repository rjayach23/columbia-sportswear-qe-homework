import { fromPairs } from "./index";
export = fromPairs;
