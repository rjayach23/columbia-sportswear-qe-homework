import { dropRightWhile } from "./index";
export = dropRightWhile;
