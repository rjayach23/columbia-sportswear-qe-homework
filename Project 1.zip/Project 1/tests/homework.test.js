import { test,expect } from '@playwright/test';
import { chromium, webkit, firefox } from '@playwright/test';
import { Magentohomepage } from '../pages/Magentohomepage';
import {Cartpage} from '../pages/Cartpage';
import {Categorypage} from '../pages/Categorypage';
import {Checkoutpage} from '../pages/Checkoutpage';
import {Orderconfirmationpage} from '../pages/Orderconfirmationpage';
import {Placeanorderpage} from '../pages/Placeanorderpage';
import {Productdetailpage} from '../pages/Productdetailpage';
import { magentodemo } from '../datatables/json/constants.json';
import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';
console.log(__dirname);

//Data fetching
const records = parse(

    fs.readFileSync(path.join(__dirname, '../datatables/csv/testdata.csv')),
    {
        columns: true,
        skip_empty_lines: true,

    });

let magentohomepage,cartpage,categorypage,checkoutpage,orderconfirmationpage,placeanorderpage,productdetailpage

for (const record of records) {

    test('Launching Magento website and performing required actions ${record.testcaseid}', async ({ page }) => {

        test.setTimeout(300000);       
        const browser = await chromium.launch({ headless: false, channel: record.Browser });        
        const context = await browser.newContext();
        magentohomepage = new Magentohomepage(page);
        cartpage = new Cartpage(page);
        checkoutpage = new Checkoutpage(page);
        categorypage = new Categorypage(page);
        orderconfirmationpage =new Orderconfirmationpage(page);
        placeanorderpage=new Placeanorderpage(page);
        productdetailpage=new Productdetailpage(page);

        console.log(records.url);
        //https://magento.softwaretestingboard.com/ website
        //go to the ECommerce website home page        
        await magentohomepage.LaunchMagentohomepage(record.url); 
        await expect.soft(await magentohomepage.ValidateHomepage()).toBeVisible();     
       
       
       //Selecting product from search box
       //search for “jacket”
       await categorypage.Searchbox(record.Category);
       await page.waitForTimeout(5000); 

       // Product detail page  
       //select a random jacket from the result page
       //select a random size and color on the Product page. Select quantity “1”. Add the jacket to Cart.     
       await productdetailpage.Selectproduct(record.product);
       await page.waitForTimeout(5000); 
       await productdetailpage.Selectsize(record.size);
       await productdetailpage.Selectsize(record.Color);
       await productdetailpage.Selectqty(record.quantity);
       await page.waitForTimeout(5000); 
       await productdetailpage.AddcartBtn();
       await page.waitForTimeout(5000); 

       //Cart page
       //go to the Cart page. Confirm that there is one product in the Cart.       
       await cartpage.Cartbtn();
       await cartpage.ViewEditbtn();
       await page.waitForTimeout(5000);              
       await cartpage.Productcount();

       //checkout Page
       //go to Checkout page. Add a random email address, all shipping address information, and shipping method. Click “Next” button.
       await checkoutpage.CheckoutBtn();
       await page.waitForTimeout(5000); 
       await checkoutpage.enterEmailtextbox(record.email);
       await checkoutpage.enterfirstname(record.firstname);        
       await checkoutpage.enterLastnametextbox(record.lastname);
       await checkoutpage.enterCompanytextbox(record.company);
       await checkoutpage.enterAddress1textbox(record.address1);
       await checkoutpage.enterAddress2textbox(record.address2);
       await checkoutpage.enterAddress3textbox(record.address3);
       await checkoutpage.enterCitytextbox(record.city);       
       await checkoutpage.SelectRegiondropdown(record.Region);
       await checkoutpage.enterZiptextbox(record.Zip);
       await checkoutpage.enterPhonenumbertextbox(record.phonenumber);
       await checkoutpage.SelectRateradiobtn();
       await checkoutpage.ClickNextbtn();
       await page.waitForTimeout(5000); 
       
       // Placeanorderpage
       //confirm that the Order Summary “Order Total” is greater than $0.00. Place the order.       
       await expect.soft(await placeanorderpage.OrdersummartextVld()).toBeVisible();  
       let totalprice = await (await placeanorderpage.totalpricevld()).textContent();
       let totalpricefinal = totalprice.split('$');
       let totalpricefinalasinterger = Number(totalpricefinal[1]);

       console.log("Total price is " +"$"+totalpricefinalasinterger);
       if (totalpricefinalasinterger > 0 ) {
           console.log("Your order amount is greater than $0.00");
       }
       else {
        console.log("Your order amount is less than $0.00");           
       }     
       
       await placeanorderpage.clickPlaceanorder();
       await page.waitForTimeout(5000);

       //Orderconfirmationpage
       //confim that order was placed. print the order number.     
       await expect.soft(await orderconfirmationpage.Confirmationtxtvld()).toBeVisible();         
       await orderconfirmationpage.ordernumVld()
          
        await page.close();
    })

}
