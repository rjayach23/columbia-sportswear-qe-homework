exports.Magentohomepage =

    class Magentohomepage {

        constructor(page) {
            this.page = page;
            this.homepagetitle = this.page.getByLabel('store logo');
        }

        async LaunchMagentohomepage(value) {
            await this.page.goto(value);
        }

        async ValidateHomepage() {
            return await this.homepagetitle;
       }
       
    }