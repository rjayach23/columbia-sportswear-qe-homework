exports.Checkoutpage =
    class Checkoutpage {


        constructor(page) {
            this.page = page;            
            this.Checkoutbtn =  page.getByRole('button', { name: 'Proceed to Checkout' });
            this.Emailtextbox = page.getByRole('textbox', { name: 'Email Address * Email Address*' });          
            this.Firstnametextbox = page.getByLabel('First Name');            
            this.Lastnametextbox = page.getByLabel('Last Name');
            this.Companytextbox = page.getByLabel('Company');            
            this.Address1textbox = page.getByLabel('Street Address: Line 1');           
            this.Address2textbox = page.getByLabel('Street Address: Line 2');                 
            this.Address3textbox = page.getByLabel('Street Address: Line 3');
            this.Citytextbox = page.getByLabel('City');            
            this.Regiondropdown = page.locator('select[name="region_id"]');            
            this.Ziptextbox = page.getByLabel('Zip/Postal Code');            
            this.Phonenumbertextbox = page.getByLabel('Phone Number');
            this.Rateradiobtn = page.getByLabel('Table Rate');
            this.Nextbtn = page.getByRole('button', { name: 'Next' });          
        }

        async CheckoutBtn() {
            await this.Checkoutbtn.click();          
                   
        }
        
              
        async enterEmailtextbox(value) {
            await this.Emailtextbox.fill(value);
        }
        
        async enterfirstname(value) {
            await this.Firstnametextbox.fill(value);
        }
        
        async enterLastnametextbox(value) {
            await this.Lastnametextbox.fill(value);
        }

        async enterCompanytextbox(value) {
            await this.Companytextbox.fill(value);
        }

        async enterAddress1textbox(value) {
            await this.Address1textbox.fill(value);
        }

        async enterAddress2textbox(value) {
            await this.Address2textbox.fill(value);
        }
        async enterAddress3textbox(value) {
            await this.Address3textbox.fill(value);
        }
        async enterCitytextbox(value) {
            await this.Citytextbox.fill(value);
        }
        async SelectRegiondropdown(value) {
            await this.Regiondropdown.selectOption(value);
        }
        async enterZiptextbox(value) {
            await this.Ziptextbox.fill(value);
        }
        async enterPhonenumbertextbox(value) {
            await this.Phonenumbertextbox.fill(value);
        }
        async SelectRateradiobtn() {
            await this.Rateradiobtn.click();
        }
        async ClickNextbtn() {
            await this.Nextbtn.click();
        }
    
    }


