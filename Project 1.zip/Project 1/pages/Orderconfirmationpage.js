exports.Orderconfirmationpage =
    class Orderconfirmationpage {


        constructor(page) {
            this.page = page;            
            this.Confirmationtxt = this.page.getByText('Thank you for your purchase!');
            this.ordernumtxt = this.page.getByText('Your order # is:');
        }

        async Confirmationtxtvld() {
            return await this.Confirmationtxt;           
        }

        async ordernumVld() {
            
            let ordernumber = await this.page.getByText('Your order # is:').textContent();
    
            console.log(ordernumber);
                        
         }
        
    }