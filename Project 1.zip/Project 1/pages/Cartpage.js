exports.Cartpage =
    class Cartpage {


        constructor(page) {
            this.page = page;  
            this.cartbtn = this.page.getByRole('link', { name: ' My Cart 1 1 items' })          
            this.vieweditbtn =this.page.getByRole('link', { name: 'View and Edit Cart' })   
            this.productcount = this.page.locator('#shopping-cart-table')             
            
        }

        async Cartbtn() {            
            await this.cartbtn.click();            
        }
        async ViewEditbtn() {            
            await this.vieweditbtn.click();                        
        }

        async Productcount(value) {            
            const rowCount = await this.productcount.count();   
            if (rowCount== 1){
                console.log(rowCount + "  product is displayed as expected");
            }  else{
                console.log(rowCount + "  More than one product is displaed");
            }  
        }
        
    }