exports.Placeanorderpage =
    class Placeanorderpage {


        constructor(page) {
            this.page = page;
            this.ordersummartext = this.page.locator('span').filter({ hasText: 'Order Summary' });
            this.totalprice = this.page.getByRole('row', { name: 'Order Total $' }).locator('span');
            this.placeanorderbtn = this.page.getByRole('button', { name: 'Place Order' });
        }

        async OrdersummartextVld() {
            return await this.ordersummartext;

        }

        async totalpricevld() {
            return await this.totalprice;           

        }

        async clickPlaceanorder() {
            await this.placeanorderbtn.click();

        }
    }

