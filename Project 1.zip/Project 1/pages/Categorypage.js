exports.Categorypage =
    class Categorypage {


        constructor(page) {
            this.page = page;
            this.searchbox = this.page.getByPlaceholder('Search entire store here...');
            
           
        }

        async Searchbox(value) {
                await this.searchbox.fill(value);                 
                await this.page.getByText(value, { exact: true }).click()                        
                          
        }
    }