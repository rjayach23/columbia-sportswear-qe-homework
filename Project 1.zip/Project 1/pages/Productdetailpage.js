
exports.Productdetailpage =
    class Productdetailpage {


        constructor(page) {
            this.page = page;
            this.Qty = this.page.getByLabel('Qty');
            this.addcartbtn =this.page.getByRole('button', { name: 'Add to Cart' });                  
           
        }

        async Selectproduct(value) {           
            await this.page.getByAltText(value).click();                       
        }

        async Selectsize(value) {
            await this.page.getByLabel(value, { exact: true }).click(); 
        }

        async Selectcolor(value) {              
            await this.page.getByLabel(value).click();        
        }

        async Selectqty(value) {            
            await this.Qty.fill(value);                     
        }

        async AddcartBtn() {            
            await this.addcartbtn.click();            
        }
        
    }